using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using WebApp.Data;
using WebApp.Models;

namespace WebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly ILogger<HomeController> _logger;

        public HomeController(ApplicationDbContext context, UserManager<IdentityUser> userManager, SignInManager<IdentityUser> signInManager, ILogger<HomeController> logger)
        {
            _context = context;
            _userManager = userManager;
            _signInManager = signInManager;
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View(new RegisterViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = new IdentityUser { UserName = model.Login };
                var result = await _userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    var appUser = new AppUser { IdentityUserId = user.Id, FullName = model.FullName };
                    _context.AppUsers.Add(appUser);
                    await _context.SaveChangesAsync();

                    return RedirectToAction("Index");
                }
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }
            return View(model);
        }

        public IActionResult Login()
        {
            return View(new LoginViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.FindByNameAsync(model.Login);
                if (user != null)
                {
                    var result = await _signInManager.PasswordSignInAsync(model.Login, model.Password, isPersistent: false, lockoutOnFailure: false);
                    if (result.Succeeded)
                    {
                        _logger.LogInformation("User logged in.");
                        return RedirectToAction("Dashboard");
                    }
                    else
                    {
                        _logger.LogWarning("Invalid password.");
                    }
                }
                else
                {
                    _logger.LogWarning("User not found.");
                }
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
            }
            return View(model);
        }

        [Authorize]
        public async Task<IActionResult> Dashboard(string from = null, DateTime? fromDate = null, DateTime? toDate = null, string status = "all", string sortOrder = "date")
        {
            var user = await _userManager.FindByNameAsync(User.Identity.Name);
            if (user == null)
            {
                return NotFound("User not found.");
            }

            var appUser = await _context.AppUsers.FirstOrDefaultAsync(u => u.IdentityUserId == user.Id);

            var messagesQuery = _context.Messages.Where(m => m.To == User.Identity.Name);

            if (!string.IsNullOrEmpty(from))
            {
                messagesQuery = messagesQuery.Where(m => m.From == from);
            }

            if (fromDate.HasValue)
            {
                messagesQuery = messagesQuery.Where(m => m.SentDate >= fromDate.Value);
            }

            if (toDate.HasValue)
            {
                messagesQuery = messagesQuery.Where(m => m.SentDate <= toDate.Value);
            }

            if (status == "unread")
            {
                messagesQuery = messagesQuery.Where(m => !m.IsRead);
            }

            messagesQuery = sortOrder switch
            {
                "date_desc" => messagesQuery.OrderByDescending(m => m.SentDate),
                "from" => messagesQuery.OrderBy(m => m.From),
                "from_desc" => messagesQuery.OrderByDescending(m => m.From),
                _ => messagesQuery.OrderBy(m => m.SentDate),
            };

            var messages = await messagesQuery.ToListAsync();

            ViewData["User"] = appUser;
            ViewData["Messages"] = messages;
            ViewData["CurrentSort"] = sortOrder;
            return View(appUser);
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> SendMessage(string to, string subject, string text)
        {
            var recipient = await _userManager.FindByNameAsync(to);
            if (recipient == null)
            {
                ModelState.AddModelError("", "Recipient does not exist");
                return RedirectToAction("Dashboard");
            }

            var message = new Message
            {
                From = User.Identity.Name,
                To = to,
                Subject = subject,
                Text = text,
                SentDate = DateTime.Now,
                IsRead = false
            };

            _context.Messages.Add(message);
            await _context.SaveChangesAsync();
            return RedirectToAction("Dashboard");
        }

        [Authorize]
        public async Task<IActionResult> MarkAsRead(int messageId)
        {
            var message = await _context.Messages.FindAsync(messageId);
            if (message == null || message.To != User.Identity.Name)
            {
                return NotFound("Message not found.");
            }

            message.IsRead = true;
            _context.Messages.Update(message);
            await _context.SaveChangesAsync();

            return Ok();
        }

        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Index");
        }
    }
}
