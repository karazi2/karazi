using System.ComponentModel.DataAnnotations;

namespace WebApp.Models
{
    public class AppUser
    {
        [Key]
        public string IdentityUserId { get; set; }

        [Required]
        public string FullName { get; set; }
    }
}
