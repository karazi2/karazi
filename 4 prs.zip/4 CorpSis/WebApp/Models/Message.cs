using System;
using System.ComponentModel.DataAnnotations;

namespace WebApp.Models
{
    public class Message
    {
        public int Id { get; set; }

        [Required]
        public string From { get; set; }

        [Required]
        public string To { get; set; }

        [Required]
        public string Subject { get; set; }

        [Required]
        public string Text { get; set; }

        public DateTime SentDate { get; set; }

        public bool IsRead { get; set; }
    }
}
